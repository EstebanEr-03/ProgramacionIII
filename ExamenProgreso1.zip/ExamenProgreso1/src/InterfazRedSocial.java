import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class InterfazRedSocial extends JFrame {


    private JPanel JPanelPrincipal;
    private JTabbedPane tabbedPane1;
    private JPanel JpanelAgregarParticipante;
    private JPanel JPanelBuscarParticipante;
    private JPanel JPanelDatosPredeterminados;
    private JPanel JPanelAdministracionDeRed;
    private JPanel JPanelMostrarParticipantesActivos;
    private JTextPane textPaneId;
    private JTextPane textPaneNombreCompleto;
    private JTextPane textPaneEdad;
    private JTextPane textPanePrioridad;
    private JTextPane textPaneAmigos;
    private JButton buttonAgregar;
    private JTextPane textPaneBuscarID;
    private JButton buscarButton;
    private JTextArea textAreaMostrarParticipantes;
    private JButton buttonActivarParticipantes;
    private JButton ButtonQuemarDatos;
    private JTextArea textAreaDatosQuemados;

    SocialNetwork s1;
    static Stack<Persona> pila1=new Stack<>();
    static Queue<Persona> cola1= new LinkedList<>();
    static Persona personaEncontrada;
    static Persona personaBuscada;
    Persona personaA=new Persona(1727,20,50,6,"Esteban Enriquez");
    Persona personaB=new Persona(1728,20,20,7,"Juan Enriquez");
    Persona personaC=new Persona(1729,20,100,4,"Junior Enriquez");
    Persona personaD=new Persona(1730,20,10,9,"Diego Enriquez");
    Persona personaE=new Persona(1731,20,15,8,"Sebas Enriquez");
    Persona personaF=new Persona(1732,20,55,8,"Oscar Enriquez");
    Persona persona1;


    public InterfazRedSocial(){
        add(JPanelPrincipal);
        setSize(300,200);
        setLocationRelativeTo(null);

        setTitle("Examen SocialNetwork");

        buttonAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Persona personaIngresadaPorUsuario=new Persona(Integer.valueOf(textPaneId.getText()),Integer.valueOf(textPaneEdad.getText()),Integer.valueOf(textPanePrioridad.getText()),Integer.valueOf(textPaneAmigos.getText()), textPaneNombreCompleto.getText());
                cola1.add(personaIngresadaPorUsuario);
                System.out.println("Se ingreso a la cola");
            }
        });
        buscarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int idBuscada;
                idBuscada=Integer.valueOf(textPaneBuscarID.getText());


                /*metodoBuscar(idBuscada);
                textAreaMostrarParticipantes.setText(metodoBuscar(idBuscada).toString());*/


                for (int i=0;i< cola1.size();i++){
                    personaBuscada=cola1.remove();
                    if (personaBuscada.getId()==idBuscada){
                        personaEncontrada=personaBuscada;
                        System.out.println("Se ha encontrado a la persona"+personaEncontrada);
                        textAreaMostrarParticipantes.setText(personaEncontrada.toString());
                        pila1.push(personaEncontrada);

                    }else{
                        textAreaMostrarParticipantes.setText("NO EXISTE ESTE USUARIO");
                        pila1.push(personaBuscada);
                    }

                }
                for (int i=0;i< pila1.size();i++){
                    //s1.colaPersonas.add(pila1.pop());
                    cola1.add(pila1.pop());
                }
            }
        });


        ButtonQuemarDatos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cola1.add(personaA);
                cola1.add(personaB);
                cola1.add(personaC);
                cola1.add(personaD);
                cola1.add(personaE);
                cola1.add(personaF);
                textAreaDatosQuemados.setText(cola1.toString());
            }
        });
    }
   /*public static Persona metodoBuscar(int id){
        Persona personaBuscada;


        for (int i=0;i< s1.colaPersonas.size();i++){
            personaBuscada=s1.colaPersonas.remove();
            if (personaBuscada.getId()==id){
                personaEncontrada=personaBuscada;
                System.out.println("Se ha encontrado a la persona"+personaEncontrada);
                return personaEncontrada;
            }

        }
        return personaEncontrada;
    }*/
}
