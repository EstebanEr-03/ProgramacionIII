import java.util.LinkedList;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Stack;

public class SocialNetwork {
    Queue<Persona> colaPersonas= new LinkedList<>();
    Queue<Persona> colaPersonasPrioridad= new PriorityQueue<>();
    Stack<Persona> pilaPersonasEliminadas=new Stack<>();
}
